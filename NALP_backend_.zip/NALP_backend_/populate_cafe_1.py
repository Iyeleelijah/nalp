from sqlalchemy.orm import sessionmaker
from database import engine, Base  # Import your engine and Base
from models import Category, Subcategory, Item, Section  # Import your models

categories_data = [
    {
        "name": "Cafe 1",
        "subcategories": [
            {
                "name": "Bread Warmers",
                "products": [
                    {"name": "Bread warmer sm", "price": 1200,
                     "callback_data": "Bread warmer|₦1200|Cafe 1"},
                    {"name": "Big size breadwarmer with 2 sausages", "price": 2000,
                        "callback_data": "Big size breadwarmer with 2 sausages|₦2000|Cafe 1"},
                    {"name": "Big size breadwarmer with 3 sausages", "price": 2300,
                        "callback_data": "Big size breadwarmer with 3 sausages|₦2300|Cafe 1"},
                    {"name": "Big size bread warmer with 1 sausage", "price": 1700,
                        "callback_data": "Big size bread warmer with 1 sausage|₦1700|Cafe 1"},
                    {"name": "Small size bread warmer with 1 sausage", "price": 1500,
                        "callback_data": "Small size bread warmer with 1 sausage|₦1500|Cafe 1"}
                ]
            },
            {
                "name": "Borito Chicken",
                "products": [
                    {"name": "Super pack with chicken and 3 sausages", "price": 3300,
                     "callback_data": "Super pack with chicken and 3 sausages|₦3300|Cafe 1"},
                    {"name": "Super pack with chicken and 2 sausages", "price": 2900,
                     "callback_data": "Super pack with chicken and 2 sausages|₦2900|Cafe 1"},
                    {"name": "Super pack with chicken and 1 sausage", "price": 2650,
                     "callback_data": "Super pack with chicken and 1 sausage|₦2650|Cafe 1"},
                    {"name": "Mega pack with chicken and 3 sausages", "price": 3950,
                     "callback_data": "Mega pack with chicken and 3 sausages|₦3950|Cafe 1"},
                    {"name": "Mega pack with chicken and 2 sausages", "price": 3700,
                     "callback_data": "Mega pack with chicken and 2 sausages|₦3700|Cafe 1"},
                    {"name": "Mega pack with chicken with 1 sausage", "price": 3450,
                     "callback_data": "Mega pack with chicken with 1 sausage|₦3450|Cafe 1"},
                    {"name": "Regular pack with chicken and 3 sausages", "price": 2450,
                     "callback_data": "Regular pack with chicken and 3 sausages|₦2450|Cafe 1"},
                    {"name": "Regular pack with chicken with 2 sausages", "price": 2200,
                     "callback_data": "Regular pack with chicken with 2 sausages|₦2200|Cafe 1"},
                    {"name": "Regular pack with chicken with 1 sausage", "price": 1950,
                     "callback_data": "Regular pack with chicken with 1 sausage|₦1950|Cafe 1"},
                    {"name": "SAUSAGE ONLY", "price": 300,
                     "callback_data": "SAUSAGE ONLY|₦300|Cafe 1"},
                    {"name": "MEGA CHICKEN ONLY", "price": 3000,
                     "callback_data": "MEGA CHICKEN ONLY|₦3000|Cafe 1"},
                    {"name": "Super chicken only", "price": 1500,
                     "callback_data": "Super chicken only|₦1500|Cafe 1"},
                    {"name": "REGULAR CHICKEN ONLY", "price": 1000,
                     "callback_data": "REGULAR CHICKEN ONLY|₦1000|Cafe 1"}
                ]
            },
            {
                "name": "Waffles",
                "products": [
                    {"name": "Sausage", "price": 150,
                        "callback_data": "Sausage|₦150|Cafe 1"},
                    {"name": "2 circles with pack", "price": 1350,
                     "callback_data": "2 circles with pack|₦1350|Cafe 1"},
                    {"name": "3 circles with pack", "price": 1950,
                     "callback_data": "3 circles with pack|₦1950|Cafe 1"},
                    {"name": "Fried egg", "price": 150,
                     "callback_data": "Fried egg|₦150|Cafe 1"},
                    {"name": "Egg sauce", "price": 200,
                     "callback_data": "Egg sauce|₦200|Cafe 1"},
                    {"name": "Diced sausage", "price": 200,
                     "callback_data": "Diced sausage|₦200|Cafe 1"},
                    {"name": "Vanilla circle", "price": 600,
                     "callback_data": "Vanilla circle|₦600|Cafe 1"},
                    {"name": "Strawberry circle", "price": 600,
                     "callback_data": "Strawberry circle|₦600|Cafe 1"},
                    {"name": "Chocolate circle", "price": 600,
                     "callback_data": "Chocolate circle|₦600|Cafe 1"},
                    {"name": "1 circle with pack", "price": 750,
                     "callback_data": "1 circle with pack|₦750|Cafe 1"}
                ]
            },
            {
                "name": "Pizza Burgers",
                "products": [
                    {"name": "Regular pizza burger", "price": 1200,
                     "callback_data": "Regular pizza burger|₦1200|Cafe 1"},
                    {"name": "Pizza burger plus extra sausage", "price": 2000,
                     "callback_data": "Pizza burger plus extra sausage|₦2000|Cafe 1"},
                    {"name": "Pizza burger plus ham", "price": 2000,
                     "callback_data": "Pizza burger plus ham|₦2000|Cafe 1"},
                    {"name": "Egg pizza burger", "price": 1500,
                     "callback_data": "Egg pizza burger|₦1500|Cafe 1"}
                ]
            }, {
                "name": "Pizzas",
                "products": [
                    {"name": "EXTRA BEEF", "price": 500,
                     "callback_data": "EXTRA BEEF|₦500|Cafe 1"},
                    {"name": "EXTRA CHICKEN", "price": 500,
                     "callback_data": "EXTRA CHICKEN|₦500|Cafe 1"},
                    {"name": "EXTRA CHEESE", "price": 1000,
                     "callback_data": "EXTRA CHEESE|₦1000|Cafe 1"},
                    {"name": "BURGER", "price": 1500,
                        "callback_data": "BURGER|₦1500|Cafe 1"},
                    {"name": "CHEESE BURGER", "price": 1800,
                     "callback_data": "CHEESE BURGER|₦1800|Cafe 1"},
                    {"name": "CHOWDOME BURGER", "price": 1900,
                     "callback_data": "CHOWDOME BURGER|₦1900|Cafe 1"},
                    {"name": "BEEF SUYA PIZZA (SMALL)", "price": 2500,
                     "callback_data": "BEEF SUYA PIZZA (SMALL)|₦2500|Cafe 1"},
                    {"name": "BEEF BBQ PIZZA (SMALL)", "price": 2500,
                     "callback_data": "BEEF BBQ PIZZA (SMALL)|₦2500|Cafe 1"},
                    {"name": "DODO PIZZA (SMALL)", "price": 2700,
                     "callback_data": "DODO PIZZA (SMALL)|₦2700|Cafe 1"},
                    {"name": "BEEF SUYA PIZZA (MEDIUM)", "price": 3000,
                     "callback_data": "BEEF SUYA PIZZA (MEDIUM)|₦3000|Cafe 1"},
                    {"name": "BEEF BBQ PIZZA (MEDIUM)",
                     "price": 3000, "callback_data": "BEEF BBQ PIZZA (MEDIUM)|₦3000|Cafe 1"},
                    {"name": "DODO PIZZA (MEDIUM)",
                     "price": 3300, "callback_data": "DODO PIZZA (MEDIUM)|₦3300|Cafe 1"},
                    {"name": "BEEF SUYA PIZZA (BIG)",
                     "price": 5000, "callback_data": "BEEF SUYA PIZZA (BIG)|₦5000|Cafe 1"},
                    {"name": "BEEF BBQ PIZZA (BIG)",
                     "price": 5000, "callback_data": "BEEF BBQ PIZZA (BIG)|₦5000|Cafe 1"}
                ]
            }, {
                "name": "CU Pizzas",
                "products": [
                    {"name": "Regular pizza", "price": 1800,
                     "callback_data": "Regular pizza|₦1800|Cafe 1"},
                    {"name": "Extra chicken", "price": 1000,
                     "callback_data": "Extra chicken|₦1000|Cafe 1"},
                    {"name": "Extra cheese", "price": 1500,
                     "callback_data": "Extra cheese|₦1500|Cafe 1"},
                    {"name": "Extra sausage", "price": 1000,
                     "callback_data": "Extra sausage|₦1000|Cafe 1"},
                    {"name": "Extra gizzard", "price": 1000,
                     "callback_data": "Extra gizzard|₦1000|Cafe 1"},
                    {"name": "Peperoni pizza", "price": 2500,
                     "callback_data": "Peperoni pizza|₦2500|Cafe 1"},
                    {"name": "Pizza deluxe", "price": 4500,
                     "callback_data": "Pizza deluxe|₦4500|Cafe 1"},
                    {"name": "Gizzard pizza", "price": 3500,
                     "callback_data": "Gizzard pizza|₦3500|Cafe 1"},
                    {"name": "Chicken lovers pizza", "price": 6000,
                     "callback_data": "Chicken lovers pizza|₦6000|Cafe 1"},
                    {"name": "Cheese lovers pizza", "price": 6000,
                     "callback_data": "Cheese lovers pizza|₦6000|Cafe 1"},
                    {"name": "Standard pizza", "price": 3500,
                     "callback_data": "Standard pizza|₦3500|Cafe 1"}
                ]
            }, {
                "name": "Grills and Boli",
                "products": [
                    {"name": "Boli plus pack", "price": 1600,
                     "callback_data": "Boli plus pack|₦1600|Cafe 1"},
                    {"name": "Egg", "price": 300,
                        "callback_data": "Egg|₦300|Cafe 1"},
                    {"name": "Beef", "price": 200,
                        "callback_data": "Beef|₦200|Cafe 1"},
                    {"name": "Ponmo", "price": 100,
                        "callback_data": "Ponmo|₦100|Cafe 1"},
                    {"name": "Spoon of pepper sauce", "price": 300,
                     "callback_data": "Spoon of pepper sauce|₦300|Cafe 1"},
                    {"name": "Spoon of stew", "price": 200,
                     "callback_data": "Spoon of stew|₦200|Cafe 1"},
                    {"name": "Sausage", "price": 300,
                        "callback_data": "Sausage|₦300|Cafe 1"},
                    {"name": "Pack", "price": 200,
                        "callback_data": "Pack|₦200|Cafe 1"}
                ]
            }, {
                "name": "Kingsway Fruits",
                "products": [
                    {"name": "Fruit salad (big)", "price": 1500,
                     "callback_data": "Fruit salad (big)|₦1500|Cafe 1"},
                    {"name": "Pepper plus onions", "price": 600,
                     "callback_data": "Pepper plus onions|₦600|Cafe 1"},
                    {"name": "Mixed veggies", "price": 600,
                     "callback_data": "Mixed veggies|₦600|Cafe 1"},
                    {"name": "Lemonade plus pineapple", "price": 1500,
                     "callback_data": "Lemonade plus pineapple|₦1500|Cafe 1"},
                    {"name": "Lemonade juice", "price": 1500,
                     "callback_data": "Lemonade juice|₦1500|Cafe 1"},
                    {"name": "Fruit salad (medium)", "price": 1300,
                     "callback_data": "Fruit salad (medium)|₦1300|Cafe 1"},
                    {"name": "Tiger nut juice", "price": 1500,
                     "callback_data": "Tiger nut juice|₦1500|Cafe 1"},
                    {"name": "Pineapple juice", "price": 2000,
                     "callback_data": "Pineapple juice|₦2000|Cafe 1"},
                    {"name": "Carrot plus spring onion", "price": 600,
                     "callback_data": "Carrot plus spring onion|₦600|Cafe 1"},
                    {"name": "Sweetened date smoothie", "price": 1000,
                     "callback_data": "Sweetened date smoothie|₦1000|Cafe 1"},
                    {"name": "Pineapple plus ginger juice", "price": 1500,
                     "callback_data": "Pineapple plus ginger juice|₦1500|Cafe 1"},
                    {"name": "Beetroot smoothie (small)", "price": 1500,
                     "callback_data": "Beetroot smoothie (small)|₦1500|Cafe 1"},
                    {"name": "Beetroot smoothie (large)", "price": 2000,
                     "callback_data": "Beetroot smoothie (large)|₦2000|Cafe 1"}
                ]
            },
            {
                "name": "Waffledom",
                "products": [
                    {"name": "Circle chocolate waffles", "price": 650,
                     "callback_data": "Circle chocolate waffles|₦650|Cafe 1"},
                    {"name": "Square chocolate waffles", "price": 350,
                     "callback_data": "Square chocolate waffles|₦350|Cafe 1"},
                    {"name": "Whipped cream", "price": 700,
                     "callback_data": "Whipped cream|₦700|Cafe 1"},
                    {"name": "Square vanilla waffles", "price": 350,
                     "callback_data": "Square vanilla waffles|₦350|Cafe 1"},
                    {"name": "Square strawberry waffles", "price": 350,
                     "callback_data": "Square strawberry waffles|₦350|Cafe 1"},
                    {"name": "Circle strawberry waffles", "price": 650,
                     "callback_data": "Circle strawberry waffles|₦650|Cafe 1"},
                    {"name": "Circle vanilla waffles", "price": 650,
                     "callback_data": "Circle vanilla waffles|₦650|Cafe 1"},
                    {"name": "Dark chocolate", "price": 700,
                     "callback_data": "Dark chocolate|₦700|Cafe 1"},
                    {"name": "Wafflebite", "price": 1400,
                     "callback_data": "Wafflebite|₦1400|Cafe 1"},
                    {"name": "White chocolate", "price": 700,
                     "callback_data": "White chocolate|₦700|Cafe 1"},
                    {"name": "Nutella", "price": 1000,
                        "callback_data": "Nutella|₦1000|Cafe 1"},
                    {"name": "Oreo", "price": 500,
                        "callback_data": "Oreo|₦500|Cafe 1"},
                    {"name": "Sprinkles", "price": 500,
                     "callback_data": "Sprinkles|₦500|Cafe 1"},
                    {"name": "Egg", "price": 300,
                        "callback_data": "Egg|₦300|Cafe 1"},
                    {"name": "Sausage", "price": 300,
                        "callback_data": "Sausage|₦300|Cafe 1"},
                    {"name": "Pack", "price": 150,
                        "callback_data": "Pack|₦150|Cafe 1"}
                ]
            }, {
                "name": "Yamarita Joint",
                "products": [
                    {"name": "Royals pack plus 1 kebab", "price": 2400,
                     "callback_data": "Royals pack plus 1 kebab|₦2400|Cafe 1"},
                    {"name": "Kings pack plus 1 kebab", "price": 2800,
                     "callback_data": "Kings pack plus 1 kebab|₦2800|Cafe 1"},
                    {"name": "Delish pack plus 1 kebab", "price": 2000,
                     "callback_data": "Delish pack plus 1 kebab|₦2000|Cafe 1"},
                    {"name": "Regular pack", "price": 1700,
                     "callback_data": "Regular pack|₦1700|Cafe 1"},
                    {"name": "Kebab", "price": 400,
                        "callback_data": "Kebab|₦400|Cafe 1"}
                ]
            }, {
                "name": "Suya Academy",
                "products": [
                    {"name": "1 stick of beef", "price": 500,
                     "callback_data": "1 stick of beef|₦500|Cafe 1"},
                    {"name": "1 stick of fat", "price": 300,
                     "callback_data": "1 stick of fat|₦300|Cafe 1"},
                    {"name": "2 sticks of fat", "price": 500,
                     "callback_data": "2 sticks of fat|₦500|Cafe 1"},
                    {"name": "Special suya", "price": 500,
                     "callback_data": "Special suya|₦500|Cafe 1"}
                ]
            }, {
                "name": "Suya Spot",
                "products": [
                    {"name": "2 sticks of fat", "price": 500,
                     "callback_data": "2 sticks of fat|₦500|Cafe 1"},
                    {"name": "1 stick of beef", "price": 500,
                     "callback_data": "1 stick of beef|₦500|Cafe 1"}
                ]
            },
            {
                "name": "Yam and Fish",
                "products": [
                    {"name": "1 catfish, yam and potatoes", "price": 3500,
                     "callback_data": "1 catfish, yam and potatoes|₦3500|Cafe 1"},
                    {"name": "1/2 catfish, yam and potatoes", "price": 2200,
                     "callback_data": "1/2 catfish, yam and potatoes|₦2200|Cafe 1"},
                    {"name": "1 croaker, yam and potatoes", "price": 4000,
                     "callback_data": "1 croaker, yam and potatoes|₦4000|Cafe 1"},
                    {"name": "Yam and potatoes only", "price": 1500,
                     "callback_data": "Yam and potatoes only|₦1500|Cafe 1"},
                    {"name": "1/2 fish only", "price": 1200,
                     "callback_data": "1/2 fish only|₦1200|Cafe 1"},
                    {"name": "1 tilapia, yam and potatoes", "price": 4000,
                     "callback_data": "1 tilapia, yam and potatoes|₦4000|Cafe 1"}
                ]
            }
        ]
    },

]


Base.metadata.create_all(bind=engine)


def populate_database(categories_data):
    # Create a new session
    Session = sessionmaker(bind=engine)
    session = Session()

    # Create a section instance (assuming you want to create a single section for all categories)
    section = Section(name="Cafe 1")
    session.add(section)
    session.flush()  # Flush to get the section ID

    # Iterate through the categories_data
    for category_data in categories_data:
        # Create a new category instance with the section_id
        category = Category(
            name=category_data["name"], section_id=section.id, callback_data=category_data["name"])
        session.add(category)
        session.flush()  # Flush to get the category ID for subcategories

        for subcategory_data in category_data["subcategories"]:
            # Create a new subcategory instance with callback_data
            subcategory = Subcategory(
                name=subcategory_data["name"],
                category=category,
                callback_data=subcategory_data.get(
                    "callback_data", subcategory_data["name"])  # Add this line
            )
            session.add(subcategory)
            session.flush()  # Flush to get the subcategory ID for items

            for product_data in subcategory_data["products"]:
                # Create a new item instance
                item = Item(
                    name=product_data["name"],
                    price=product_data.get("price", 0.0),
                    subcategory=subcategory,
                    description=product_data.get("callback_data", ""),
                    is_available=product_data.get("is_available", True),
                    callback_data=product_data.get(
                        "callback_data", product_data["callback_data"])
                )
                session.add(item)

    session.commit()  # Commit all changes to the database
    session.close()  # Close the session
    print("Database population successful")

populate_database(categories_data)
