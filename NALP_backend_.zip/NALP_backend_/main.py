# main.py
from fastapi import FastAPI, Depends, HTTPException, status, Header
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, timedelta
import jwt
from jwt.exceptions import InvalidTokenError
from passlib.context import CryptContext
import uvicorn
import os
from database import get_db, engine
import models, schemas
from models import Base

# Create the database tables
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Telegram Food Ordering Bot API")

# Authentication
SECRET_KEY = "your-secret-key-change-this"  # In production, use environment variable
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24  # 1 day

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# Helper functions for authentication
def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def decode_token(token):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except InvalidTokenError:
        return None

async def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    payload = decode_token(token)
    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    user_id = payload.get("sub")
    if user_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user

async def get_current_admin(current_user: models.User = Depends(get_current_user)):
    if current_user.role != models.UserRole.ADMIN and current_user.role != models.UserRole.SUPERADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions",
        )
    return current_user

async def get_current_superadmin(current_user: models.User = Depends(get_current_user)):
    if current_user.role != models.UserRole.SUPERADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions",
        )
    return current_user

# Authentication routes
@app.post("/token", response_model=schemas.Token)
async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == form_data.username).first()
    if not user or not verify_password(form_data.password, user.password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    if user.role not in [models.UserRole.ADMIN, models.UserRole.SUPERADMIN]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions",
        )
    
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": str(user.id)}, expires_delta=access_token_expires
    )
    
    # Store token in database
    token_exp = datetime.utcnow() + access_token_expires
    db_token = models.Token(
        user_id=user.id,
        token=access_token,
        expires_at=token_exp
    )
    db.add(db_token)
    db.commit()
    
    return {"access_token": access_token, "token_type": "bearer"}

# User routes
@app.post("/users/register", response_model=schemas.User)
async def register_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    # Check if user with telegram_id already exists
    db_user = db.query(models.User).filter(models.User.telegram_id == user.telegram_id).first()
    if db_user:
        raise HTTPException(status_code=400, detail="User already registered")
    
    new_user = models.User(
        telegram_id=user.telegram_id,
        name=user.name,
        phone=user.phone,
        role=models.UserRole.USER
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user

@app.post("/admin/create", response_model=schemas.AdminUser)
async def create_admin(
    admin: schemas.AdminCreate, 
    current_user: models.User = Depends(get_current_superadmin),
    db: Session = Depends(get_db)
):
    # Check if email already exists
    db_user = db.query(models.User).filter(models.User.email == admin.email).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    hashed_password = get_password_hash(admin.password)
    new_admin = models.User(
        name=admin.name,
        phone=admin.phone,
        email=admin.email,
        password=hashed_password,
        role=models.UserRole.ADMIN
    )
    db.add(new_admin)
    db.commit()
    db.refresh(new_admin)
    return new_admin

@app.post("/superadmin/create", response_model=schemas.AdminUser)
async def create_superadmin(admin: schemas.AdminCreate, db: Session = Depends(get_db)):
    # Check if any superadmin exists
    superadmin_exists = db.query(models.User).filter(models.User.role == models.UserRole.SUPERADMIN).first()
    
    # If superadmin exists, only another superadmin can create a new one
    if superadmin_exists:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="A superadmin already exists. Only existing superadmins can create new ones."
        )
    
    # Check if email already exists
    db_user = db.query(models.User).filter(models.User.email == admin.email).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    hashed_password = get_password_hash(admin.password)
    new_superadmin = models.User(
        name=admin.name,
        phone=admin.phone,
        email=admin.email,
        password=hashed_password,
        role=models.UserRole.SUPERADMIN
    )
    db.add(new_superadmin)
    db.commit()
    db.refresh(new_superadmin)
    return new_superadmin

@app.post("/users/become_waiter/{telegram_id}", response_model=schemas.User)
async def become_waiter(telegram_id: str, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.telegram_id == telegram_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    user.role = models.UserRole.WAITER
    db.commit()
    db.refresh(user)
    return user

# Section routes


@app.post("/sections/", response_model=schemas.Section)
async def create_section(
    section: schemas.SectionCreate,
    current_user: models.User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    db_section = models.Section(
        name=section.name, callback_data=section.callback_data)  # Add callback_data
    db.add(db_section)
    db.commit()
    db.refresh(db_section)
    return db_section

@app.get("/sections/", response_model=List[schemas.Section])
async def get_sections(db: Session = Depends(get_db)):
    sections = db.query(models.Section).all()
    return sections

# Category routes


@app.post("/categories/", response_model=schemas.Category)
async def create_category(
    category: schemas.CategoryCreate,
    current_user: models.User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    db_category = models.Category(name=category.name, section_id=category.section_id,
                                  callback_data=category.callback_data)  # Add callback_data
    db.add(db_category)
    db.commit()
    db.refresh(db_category)
    return db_category

# @app.get("/categories/", response_model=List[schemas.Category])
# async def get_categories(section_id: Optional[int] = None, db: Session = Depends(get_db)):
#     query = db.query(models.Category)
#     if section_id:
#         query = query.filter(models.Category.section_id == section_id)
#     categories = query.all()
#     return categories


@app.get("/categories/", response_model=List[schemas.Category])
async def get_categories(section_name: Optional[str] = None, db: Session = Depends(get_db)):
    query = db.query(models.Category)
    if section_name:
        query = query.join(models.Section).filter(
            models.Section.name == section_name)
    categories = query.all()
    return categories

@app.get("/categories_all/", response_model=List[schemas.Category])
async def get_all_categories(db: Session = Depends(get_db)):
    return db.query(models.Category).all()


@app.delete("/categories/{category_id}")
async def delete_category(
    category_id: int, 
    current_user: models.User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    category = db.query(models.Category).filter(models.Category.id == category_id).first()
    if not category:
        raise HTTPException(status_code=404, detail="Category not found")
    
    db.delete(category)
    db.commit()
    return {"detail": "Category deleted"}



# Endpoint to get all categories

@app.get("/categories_all/", response_model=List[schemas.Category])
async def get_categories(db: Session = Depends(get_db)):
    categories = db.query(models.Category).all()
    return categories


# Subcategory routes


@app.post("/subcategories/", response_model=schemas.Subcategory)
async def create_subcategory(
    subcategory: schemas.SubcategoryCreate,
    current_user: models.User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    db_subcategory = models.Subcategory(name=subcategory.name, category_id=subcategory.category_id,
                                        callback_data=subcategory.callback_data)  # Add callback_data
    db.add(db_subcategory)
    db.commit()
    db.refresh(db_subcategory)
    return db_subcategory

# @app.get("/subcategories/", response_model=List[schemas.Subcategory])
# async def get_subcategories(category_id: Optional[int] = None, db: Session = Depends(get_db)):
#     query = db.query(models.Subcategory)
#     if category_id:
#         query = query.filter(models.Subcategory.category_id == category_id)
#     subcategories = query.all()
#     return subcategories


@app.get("/subcategories/", response_model=List[schemas.Subcategory])
async def get_subcategories(category_name: Optional[str] = None, db: Session = Depends(get_db)):
    query = db.query(models.Subcategory)
    if category_name:
        category = db.query(models.Category).filter(
            models.Category.name == category_name).first()
        if not category:
            raise HTTPException(status_code=404, detail="Category not found")
        query = query.filter(models.Subcategory.category_id == category.id)
    subcategories = query.all()
    return subcategories


@app.get("/subcategories_all/", response_model=List[schemas.Subcategory])
async def get_all_subcategories(db: Session = Depends(get_db)):
    return db.query(models.Subcategory).all()


@app.delete("/subcategories/{subcategory_id}")
async def delete_subcategory(
    subcategory_id: int, 
    current_user: models.User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    subcategory = db.query(models.Subcategory).filter(models.Subcategory.id == subcategory_id).first()
    if not subcategory:
        raise HTTPException(status_code=404, detail="Subcategory not found")
    
    db.delete(subcategory)
    db.commit()
    return {"detail": "Subcategory deleted"}

# Item routes


@app.post("/items/", response_model=schemas.Item)
async def create_item(
    item: schemas.ItemCreate,
    current_user: models.User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    db_item = models.Item(
        name=item.name,
        price=item.price,
        subcategory_id=item.subcategory_id,
        description=item.description,
        is_available=item.is_available,
        callback_data=item.callback_data  # Add callback_data
    )
    db.add(db_item)
    db.commit()
    db.refresh(db_item)
    return db_item

# @app.get("/items/", response_model=List[schemas.Item])
# async def get_items(subcategory_id: Optional[int] = None, db: Session = Depends(get_db)):
#     query = db.query(models.Item)
#     if subcategory_id:
#         query = query.filter(models.Item.subcategory_id == subcategory_id)
#     items = query.all()
#     return items

@app.get("/items_all/", response_model=List[schemas.Item])
async def get_all_items(db: Session = Depends(get_db)):
    return db.query(models.Item).all()

@app.get("/items/", response_model=List[schemas.Item])
async def get_items(subcategory_name: Optional[str] = None, db: Session = Depends(get_db)):
    query = db.query(models.Item)
    if subcategory_name:
        subcategory = db.query(models.Subcategory).filter(
            models.Subcategory.name == subcategory_name).first()
        if not subcategory:
            raise HTTPException(
                status_code=404, detail="Subcategory not found")
        query = query.filter(models.Item.subcategory_id == subcategory.id)
    items = query.all()
    return items


@app.delete("/items/{item_id}")
async def delete_item(
    item_id: int, 
    current_user: models.User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    item = db.query(models.Item).filter(models.Item.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    
    db.delete(item)
    db.commit()
    return {"detail": "Item deleted"}

# Cart routes
@app.post("/cart/add", response_model=schemas.CartItem)
async def add_to_cart(cart_item: schemas.CartItemCreate, db: Session = Depends(get_db)):
    # Get user by telegram_id
    user = db.query(models.User).filter(models.User.telegram_id == cart_item.telegram_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Check if item exists
    item = db.query(models.Item).filter(models.Item.id == cart_item.item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    
    # Check if item is already in cart for the same branch
    existing_cart_item = db.query(models.CartItem).filter(
        models.CartItem.user_id == user.id,
        models.CartItem.item_id == cart_item.item_id,
        models.CartItem.branch == cart_item.branch  # Only consider it existing if branch matches
    ).first()
    
    if existing_cart_item:
        # Update quantity
        existing_cart_item.quantity += cart_item.quantity
        db.commit()
        db.refresh(existing_cart_item)
        return existing_cart_item
    
    # Create new cart item
    db_cart_item = models.CartItem(
        user_id=user.id,
        item_id=cart_item.item_id,
        quantity=cart_item.quantity,
        branch=cart_item.branch,
        price=cart_item.price  # Store the price at the time of adding to cart
    )
    db.add(db_cart_item)
    db.commit()
    db.refresh(db_cart_item)
    return db_cart_item

@app.get("/cart/{telegram_id}", response_model=List[schemas.CartItemDetail])
async def get_cart(telegram_id: str, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.telegram_id == telegram_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    cart_items = db.query(models.CartItem).filter(models.CartItem.user_id == user.id).all()
    
    result = []
    for cart_item in cart_items:
        item = db.query(models.Item).filter(models.Item.id == cart_item.item_id).first()
        subcategory = db.query(models.Subcategory).filter(models.Subcategory.id == item.subcategory_id).first()
        category = db.query(models.Category).filter(models.Category.id == subcategory.category_id).first()
        
        result.append({
            "id": cart_item.id,
            "item_id": item.id,
            "name": item.name,
            "price": item.price,
            "quantity": cart_item.quantity,
            "total_price": item.price * cart_item.quantity,
            "category_name": category.name,
            "subcategory_name": subcategory.name
        })
    
    return result

@app.delete("/cart/{cart_item_id}")
async def remove_from_cart(cart_item_id: int, db: Session = Depends(get_db)):
    cart_item = db.query(models.CartItem).filter(models.CartItem.id == cart_item_id).first()
    if not cart_item:
        raise HTTPException(status_code=404, detail="Cart item not found")
    
    db.delete(cart_item)
    db.commit()
    return {"detail": "Item removed from cart"}

@app.delete("/cart/clear/{telegram_id}")
async def clear_cart(telegram_id: str, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.telegram_id == telegram_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    db.query(models.CartItem).filter(models.CartItem.user_id == user.id).delete()
    db.commit()
    return {"detail": "Cart cleared"}

# Checkout route
@app.post("/checkout/{telegram_id}", response_model=schemas.Order)
async def checkout(telegram_id: str, is_weekend_special: bool = False, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.telegram_id == telegram_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Get cart items
    cart_items = db.query(models.CartItem).filter(models.CartItem.user_id == user.id).all()
    if not cart_items:
        raise HTTPException(status_code=400, detail="Cart is empty")
    
    # Calculate order total and organize by category
    total_amount = 0
    category_totals = {}
    
    for cart_item in cart_items:
        item = db.query(models.Item).filter(models.Item.id == cart_item.item_id).first()
        subcategory = db.query(models.Subcategory).filter(models.Subcategory.id == item.subcategory_id).first()
        category = db.query(models.Category).filter(models.Category.id == subcategory.category_id).first()
        
        item_total = item.price * cart_item.quantity
        total_amount += item_total
        
        if category.id not in category_totals:
            category_totals[category.id] = 0
        category_totals[category.id] += item_total
    
    # Calculate delivery fee based on categories and order amounts
    delivery_fee = 0
    for category_id, amount in category_totals.items():
        # Find the appropriate delivery pricing rule
        pricing_rule = db.query(models.DeliveryPricing).filter(
            models.DeliveryPricing.category_id == category_id,
            models.DeliveryPricing.min_order_amount <= amount,
            (models.DeliveryPricing.max_order_amount >= amount) | (models.DeliveryPricing.max_order_amount == None)
        ).first()
        
        if pricing_rule:
            delivery_fee += pricing_rule.fee
    
    # Apply weekend special discount if applicable
    if is_weekend_special:
        # Get active weekend special event
        weekend_event = db.query(models.WeekendSpecialEvent).filter(
            models.WeekendSpecialEvent.is_active == True,
            models.WeekendSpecialEvent.start_date <= datetime.utcnow(),
            models.WeekendSpecialEvent.end_date >= datetime.utcnow()
        ).first()
        
        if weekend_event:
            discount = (delivery_fee * weekend_event.discount_percentage) / 100
            delivery_fee -= discount
    
    # Create order
    order = models.Order(
        user_id=user.id,
        total_amount=total_amount,
        delivery_fee=delivery_fee,
        is_weekend_special=is_weekend_special
    )
    db.add(order)
    db.commit()
    db.refresh(order)
    
    # Create order items
    for cart_item in cart_items:
        item = db.query(models.Item).filter(models.Item.id == cart_item.item_id).first()
        order_item = models.OrderItem(
            order_id=order.id,
            item_id=item.id,
            quantity=cart_item.quantity,
            price_at_order=item.price
        )
        db.add(order_item)
    
    # Clear cart
    db.query(models.CartItem).filter(models.CartItem.user_id == user.id).delete()
    
    db.commit()
    return order

# Order history
@app.get("/orders/{telegram_id}", response_model=List[schemas.OrderDetail])
async def get_order_history(telegram_id: str, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.telegram_id == telegram_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    orders = db.query(models.Order).filter(models.Order.user_id == user.id).order_by(models.Order.created_at.desc()).all()
    
    result = []
    for order in orders:
        order_items = db.query(models.OrderItem).filter(models.OrderItem.order_id == order.id).all()
        items = []
        
        for order_item in order_items:
            item = db.query(models.Item).filter(models.Item.id == order_item.item_id).first()
            items.append({
                "name": item.name,
                "price": order_item.price_at_order,
                "quantity": order_item.quantity,
                "total": order_item.price_at_order * order_item.quantity
            })
        
        result.append({
            "id": order.id,
            "date": order.created_at,
            "status": order.status,
            "total_amount": order.total_amount,
            "delivery_fee": order.delivery_fee,
            "is_weekend_special": order.is_weekend_special,
            "items": items
        })
    
    return result

# Delivery pricing routes
@app.post("/delivery-pricing/", response_model=schemas.DeliveryPricing)
async def create_delivery_pricing(
    pricing: schemas.DeliveryPricingCreate, 
    current_user: models.User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    db_pricing = models.DeliveryPricing(
        category_id=pricing.category_id,
        min_order_amount=pricing.min_order_amount,
        max_order_amount=pricing.max_order_amount,
        fee=pricing.fee
    )
    db.add(db_pricing)
    db.commit()
    db.refresh(db_pricing)
    return db_pricing

@app.get("/delivery-pricing/", response_model=List[schemas.DeliveryPricing])
async def get_delivery_pricing(db: Session = Depends(get_db)):
    pricing_rules = db.query(models.DeliveryPricing).all()
    return pricing_rules

@app.delete("/delivery-pricing/{pricing_id}")
async def delete_delivery_pricing(
    pricing_id: int, 
    current_user: models.User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    pricing = db.query(models.DeliveryPricing).filter(models.DeliveryPricing.id == pricing_id).first()
    if not pricing:
        raise HTTPException(status_code=404, detail="Pricing rule not found")
    
    db.delete(pricing)
    db.commit()
    return {"detail": "Pricing rule deleted"}

# Weekend special event routes
@app.post("/weekend-special/", response_model=schemas.WeekendSpecialEvent)
async def create_weekend_special(
    event: schemas.WeekendSpecialEventCreate, 
    current_user: models.User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    db_event = models.WeekendSpecialEvent(
        title=event.title,
        description=event.description,
        discount_percentage=event.discount_percentage,
        start_date=event.start_date,
        end_date=event.end_date,
        is_active=event.is_active
    )
    db.add(db_event)
    db.commit()
    db.refresh(db_event)
    return db_event

@app.get("/weekend-special/", response_model=List[schemas.WeekendSpecialEvent])
async def get_weekend_specials(active_only: bool = False, db: Session = Depends(get_db)):
    query = db.query(models.WeekendSpecialEvent)
    if active_only:
        query = query.filter(
            models.WeekendSpecialEvent.is_active == True,
            models.WeekendSpecialEvent.start_date <= datetime.utcnow(),
            models.WeekendSpecialEvent.end_date >= datetime.utcnow()
        )
    events = query.all()
    return events

@app.delete("/weekend-special/{event_id}")
async def delete_weekend_special(
    event_id: int, 
    current_user: models.User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    event = db.query(models.WeekendSpecialEvent).filter(models.WeekendSpecialEvent.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Weekend special event not found")
    
    db.delete(event)
    db.commit()
    return {"detail": "Weekend special event deleted"}

# Customer support routes
@app.post("/support/", response_model=schemas.SupportTicket)
async def create_support_ticket(ticket: schemas.SupportTicketCreate, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.telegram_id == ticket.telegram_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    db_ticket = models.SupportTicket(
        user_id=user.id,
        message=ticket.message
    )
    db.add(db_ticket)
    db.commit()
    db.refresh(db_ticket)
    
    # Get superadmin's telegram_id for notification
    superadmin = db.query(models.User).filter(models.User.role == models.UserRole.SUPERADMIN).first()
    
    # Return ticket with superadmin info for notification
    return {
        "id": db_ticket.id,
        "user_id": db_ticket.user_id,
        "message": db_ticket.message,
        "created_at": db_ticket.created_at,
        "status": db_ticket.status,
        "superadmin_telegram_id": superadmin.telegram_id if superadmin and superadmin.telegram_id else None
    }

@app.get("/support/", response_model=List[schemas.SupportTicket])
async def get_support_tickets(
    status: Optional[str] = None,
    current_user: models.User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    query = db.query(models.SupportTicket)
    if status:
        query = query.filter(models.SupportTicket.status == status)
    tickets = query.order_by(models.SupportTicket.created_at.desc()).all()
    return tickets

@app.put("/support/{ticket_id}/close")
async def close_support_ticket(
    ticket_id: int, 
    current_user: models.User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    ticket = db.query(models.SupportTicket).filter(models.SupportTicket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404, detail="Support ticket not found")
    
    ticket.status = "closed"
    db.commit()
    return {"detail": "Support ticket closed"}

# Admin management routes
@app.delete("/admin/{admin_id}")
async def delete_admin(
    admin_id: int, 
    current_user: models.User = Depends(get_current_superadmin),
    db: Session = Depends(get_db)
):
    admin = db.query(models.User).filter(
        models.User.id == admin_id,
        models.User.role == models.UserRole.ADMIN
    ).first()
    
    if not admin:
        raise HTTPException(status_code=404, detail="Admin not found")
    
    db.delete(admin)
    db.commit()
    return {"detail": "Admin deleted"}

@app.get("/admin/list", response_model=List[schemas.AdminUser])
async def list_admins(
    current_user: models.User = Depends(get_current_superadmin),
    db: Session = Depends(get_db)
):
    admins = db.query(models.User).filter(models.User.role == models.UserRole.ADMIN).all()
    return admins

# Bot data endpoints for telegram integration
@app.get("/bot/sections")
async def get_bot_sections(db: Session = Depends(get_db)):
    """Get all sections formatted for telegram bot inline keyboard"""
    sections = db.query(models.Section).all()
    return [{"text": section.name, "callback_data": section.name} for section in sections]

@app.get("/bot/categories/{section_name}")
async def get_bot_categories(section_name: str, db: Session = Depends(get_db)):
    """Get categories for a section formatted for telegram bot inline keyboard"""
    section = db.query(models.Section).filter(models.Section.name == section_name).first()
    if not section:
        raise HTTPException(status_code=404, detail="Section not found")
    
    categories = db.query(models.Category).filter(models.Category.section_id == section.id).all()
    return [{"text": f"{category.name} 🍔", "callback_data": f"{category.name} Menu"} for category in categories]

@app.get("/bot/subcategories/{category_name}")
async def get_bot_subcategories(category_name: str, db: Session = Depends(get_db)):
    """Get subcategories for a category formatted for telegram bot inline keyboard"""
    # Remove " Menu" suffix if present
    if category_name.endswith(" Menu"):
        category_name = category_name[:-5]
    
    category = db.query(models.Category).filter(models.Category.name == category_name).first()
    if not category:
        raise HTTPException(status_code=404, detail="Category not found")
    
    subcategories = db.query(models.Subcategory).filter(models.Subcategory.category_id == category.id).all()
    return [{"text": subcategory.name, "callback_data": subcategory.name} for subcategory in subcategories]

@app.get("/bot/items/{subcategory_name}")
async def get_bot_items(subcategory_name: str, db: Session = Depends(get_db)):
    """Get items for a subcategory formatted for telegram bot inline keyboard"""
    subcategory = db.query(models.Subcategory).filter(models.Subcategory.name == subcategory_name).first()
    if not subcategory:
        raise HTTPException(status_code=404, detail="Subcategory not found")
    
    # Get the category for this subcategory
    category = db.query(models.Category).filter(models.Category.id == subcategory.category_id).first()
    
    items = db.query(models.Item).filter(models.Item.subcategory_id == subcategory.id, models.Item.is_available == True).all()
    
    result = []
    for item in items:
        # Format price as Naira
        price_naira = f"₦{item.price}"
        callback_data = f"{item.name}|{price_naira}|{category.name}"
        text = f"{item.name} - {price_naira}"
        result.append({"text": text, "callback_data": callback_data})
    
    return result

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
