# models.py
from sqlalchemy import Boolean, Column, ForeignKey, Integer, String, Float, Text, DateTime, Table, Enum
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime
import enum

Base = declarative_base()

class UserRole(enum.Enum):
    USER = "user"
    WAITER = "waiter"
    ADMIN = "admin"
    SUPERADMIN = "superadmin"

# Fix the Order class relationship with User
class Order(Base):
    __tablename__ = "orders"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    total_amount = Column(Float)
    delivery_fee = Column(Float)
    status = Column(String, default="pending")  # pending, processing, delivered, cancelled
    created_at = Column(DateTime, default=datetime.utcnow)
    is_weekend_special = Column(Boolean, default=False)
    waiter_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    
    # Specify foreign_keys in relationships to resolve ambiguity
    user = relationship("User", back_populates="orders", foreign_keys=[user_id])
    waiter = relationship("User", foreign_keys=[waiter_id])
    order_items = relationship("OrderItem", back_populates="order")

# Then update the User class
class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    telegram_id = Column(String, unique=True, index=True)
    name = Column(String)
    phone = Column(String, nullable=True)
    email = Column(String, nullable=True, unique=True)
    password = Column(String, nullable=True)  # Hashed password for admins/superadmins
    role = Column(Enum(UserRole), default=UserRole.USER)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    cart_items = relationship("CartItem", back_populates="user")
    # Specify foreign_keys here to match the Order class
    orders = relationship("Order", back_populates="user", foreign_keys="[Order.user_id]")
    support_tickets = relationship("SupportTicket", back_populates="user")
    # Add a relationship for orders where the user is a waiter if needed
    # waiter_orders = relationship("Order", foreign_keys="[Order.waiter_id]")


class Section(Base):
    __tablename__ = "sections"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True)
    callback_data = Column(String)  # New column for callback_data

    # Relationships
    categories = relationship("Category", back_populates="section")


class Category(Base):
    __tablename__ = "categories"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    section_id = Column(Integer, ForeignKey("sections.id"))
    callback_data = Column(String)  # New column for callback_data

    # Relationships
    section = relationship("Section", back_populates="categories")
    subcategories = relationship("Subcategory", back_populates="category")


class Subcategory(Base):
    __tablename__ = "subcategories"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    category_id = Column(Integer, ForeignKey("categories.id"))
    callback_data = Column(String)  # New column for callback_data

    # Relationships
    category = relationship("Category", back_populates="subcategories")
    items = relationship("Item", back_populates="subcategory")


class Item(Base):
    __tablename__ = "items"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    price = Column(Float)
    subcategory_id = Column(Integer, ForeignKey("subcategories.id"))
    description = Column(Text, nullable=True)
    branch = Column(String)
    is_available = Column(Boolean, default=True)
    callback_data = Column(String)  # New column for callback_data

    # Relationships
    subcategory = relationship("Subcategory", back_populates="items")
    cart_items = relationship("CartItem", back_populates="item")
    order_items = relationship("OrderItem", back_populates="item")

class CartItem(Base):
    __tablename__ = "cart_items"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    item_id = Column(Integer, ForeignKey("items.id"))
    quantity = Column(Integer, default=1)
    branch = Column(String)
    
    # Relationships
    user = relationship("User", back_populates="cart_items")
    item = relationship("Item", back_populates="cart_items")


class OrderItem(Base):
    __tablename__ = "order_items"
    
    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(Integer, ForeignKey("orders.id"))
    item_id = Column(Integer, ForeignKey("items.id"))
    quantity = Column(Integer)
    price_at_order = Column(Float)  # Price at the time of order
    
    # Relationships
    order = relationship("Order", back_populates="order_items")
    item = relationship("Item", back_populates="order_items")

class DeliveryPricing(Base):
    __tablename__ = "delivery_pricing"
    
    id = Column(Integer, primary_key=True, index=True)
    category_id = Column(Integer, ForeignKey("categories.id"))
    min_order_amount = Column(Float, default=0)
    max_order_amount = Column(Float, nullable=True)
    fee = Column(Float)
    
    category = relationship("Category")

class WeekendSpecialEvent(Base):
    __tablename__ = "weekend_special_events"
    
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String)
    description = Column(Text, nullable=True)
    discount_percentage = Column(Float, default=0)
    start_date = Column(DateTime)
    end_date = Column(DateTime)
    is_active = Column(Boolean, default=False)

class SupportTicket(Base):
    __tablename__ = "support_tickets"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    message = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    status = Column(String, default="open")  # open, closed
    
    # Relationships
    user = relationship("User", back_populates="support_tickets")

class Token(Base):
    __tablename__ = "tokens"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    token = Column(String, index=True)
    expires_at = Column(DateTime)
    
    user = relationship("User")