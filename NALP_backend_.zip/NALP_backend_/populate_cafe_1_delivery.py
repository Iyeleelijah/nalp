from models import DeliveryPricing, Category  # Import your DeliveryPricing model
from sqlalchemy.orm import sessionmaker
from database import engine

# Function to populate delivery pricing


def populate_delivery_pricing():
    Session = sessionmaker(bind=engine)
    session = Session()

    # First, find the correct category for "Cafe 1" or whichever cafe you are assigning delivery fee to
    cafe_category = session.query(Category).filter_by(name="Cafe 1").first()
    if not cafe_category:
        print("Cafe 1 category not found.")
        session.close()
        return

    # Define the delivery pricing ranges and fees
    pricing_data = [
        {"min_amount": 0, "max_amount": 999.99, "fee": 250},
        {"min_amount": 1000, "max_amount": 1999.99, "fee": 350},
        {"min_amount": 2000, "max_amount": 2999.99, "fee": 450},
        {"min_amount": 3000, "max_amount": 3999.99, "fee": 550},
        {"min_amount": 4000, "max_amount": 4999.99, "fee": 650},
        {"min_amount": 5000, "max_amount": 5999.99, "fee": 750},
        {"min_amount": 6000, "max_amount": 6999.99, "fee": 850},
        {"min_amount": 7000, "max_amount": 7999.99, "fee": 950},
        {"min_amount": 8000, "max_amount": 8999.99, "fee": 1000},
        {"min_amount": 9000, "max_amount": 9999.99, "fee": 1100},
        {"min_amount": 10000, "max_amount": 10999.99, "fee": 1200},
        {"min_amount": 11000, "max_amount": 11999.99, "fee": 1300},
        {"min_amount": 12000, "max_amount": 12999.99, "fee": 1400},
        {"min_amount": 13000, "max_amount": 13999.99, "fee": 1500},
        {"min_amount": 14000, "max_amount": 14999.99, "fee": 1600},
        {"min_amount": 15000, "max_amount": 15999.99, "fee": 1700},
        {"min_amount": 16000, "max_amount": 16999.99, "fee": 1800},
        {"min_amount": 17000, "max_amount": 17999.99, "fee": 1900},
        {"min_amount": 18000, "max_amount": 18999.99, "fee": 2000},
        {"min_amount": 19000, "max_amount": 19999.99, "fee": 2100},
    ]

    # Now, insert each delivery pricing entry
    for data in pricing_data:
        delivery_pricing = DeliveryPricing(
            category_id=cafe_category.id,
            min_order_amount=data["min_amount"],
            max_order_amount=data["max_amount"],
            fee=data["fee"]
        )
        session.add(delivery_pricing)

    session.commit()
    session.close()
    print("Delivery pricing population successful")


# Call the function
populate_delivery_pricing()
