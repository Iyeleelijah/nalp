# schemas.py
from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime
from enum import Enum as PyEnum

class UserRole(str, PyEnum):
    USER = "user"
    WAITER = "waiter"
    ADMIN = "admin"
    SUPERADMIN = "superadmin"

# User schemas
class UserBase(BaseModel):
    name: str
    
class UserCreate(UserBase):
    telegram_id: str
    phone: Optional[str] = None

class AdminCreate(UserBase):
    phone: str
    email: str
    password: str

class User(UserBase):
    id: int
    telegram_id: Optional[str] = None
    phone: Optional[str] = None
    role: UserRole
    created_at: datetime
    
    class Config:
        orm_mode = True

class AdminUser(UserBase):
    id: int
    phone: str
    email: str
    role: UserRole
    created_at: datetime
    
    class Config:
        orm_mode = True

# Authentication schemas
class Token(BaseModel):
    access_token: str
    token_type: str

# Section schemas
class SectionBase(BaseModel):
    name: str

class SectionCreate(SectionBase):
    callback_data: str
    pass

class Section(SectionBase):
    id: int
    
    class Config:
        orm_mode = True

# Category schemas
class CategoryBase(BaseModel):
    name: str

class CategoryCreate(CategoryBase):
    section_id: int
    callback_data: str

class Category(CategoryBase):
    id: int
    section_id: int
    callback_data: Optional[str] = None

    class Config:
        orm_mode = True

# Subcategory schemas
class SubcategoryBase(BaseModel):
    name: str

class SubcategoryCreate(SubcategoryBase):
    category_id: int
    callback_data: str

class Subcategory(SubcategoryBase):
    id: int
    category_id: int
    callback_data: Optional[str] = None

    class Config:
        orm_mode = True

# Item schemas
class ItemBase(BaseModel):
    name: str
    price: float
    description: Optional[str] = None
    is_available: bool = True

class ItemCreate(ItemBase):
    subcategory_id: int
    callback_data: str
    # branch: str

class Item(ItemBase):
    id: int
    subcategory_id: int
    callback_data: Optional[str] = None
    
    class Config:
        orm_mode = True

# Cart schemas
class CartItemBase(BaseModel):
    quantity: int = 1

class CartItemCreate(CartItemBase):
    telegram_id: str
    item_id: str
    branch: str  

class CartItem(CartItemBase):
    id: int
    user_id: int
    item_id: str
 
    
    class Config:
        orm_mode = True

class CartItemDetail(BaseModel):
    id: int
    item_id: str
    name: str
    price: float
    quantity: int
    total_price: float
    category_name: str
    subcategory_name: str
    
    class Config:
        orm_mode = True

# Order schemas
class OrderItemDetail(BaseModel):
    name: str
    price: float
    quantity: int
    total: float

class OrderDetail(BaseModel):
    id: int
    date: datetime
    status: str
    total_amount: float
    delivery_fee: float
    is_weekend_special: bool
    items: List[OrderItemDetail]
    
    class Config:
        orm_mode = True

class Order(BaseModel):
    id: int
    user_id: int
    total_amount: float
    delivery_fee: float
    status: str
    created_at: datetime
    is_weekend_special: bool
    
    class Config:
        orm_mode = True

# Delivery pricing schemas
class DeliveryPricingBase(BaseModel):
    category_id: int
    min_order_amount: float = 0
    max_order_amount: Optional[float] = None
    fee: float

class DeliveryPricingCreate(DeliveryPricingBase):
    pass

class DeliveryPricing(DeliveryPricingBase):
    id: int
    
    class Config:
        orm_mode = True

# Weekend special event schemas
class WeekendSpecialEventBase(BaseModel):
    title: str
    description: Optional[str] = None
    discount_percentage: float
    start_date: datetime
    end_date: datetime
    is_active: bool = False

class WeekendSpecialEventCreate(WeekendSpecialEventBase):
    pass

class WeekendSpecialEvent(WeekendSpecialEventBase):
    id: int
    
    class Config:
        orm_mode = True

# Support ticket schemas
class SupportTicketBase(BaseModel):
    message: str

class SupportTicketCreate(SupportTicketBase):
    telegram_id: str

class SupportTicket(SupportTicketBase):
    id: int
    user_id: int
    created_at: datetime
    status: str
    superadmin_telegram_id: Optional[str] = None
    
    class Config:
        orm_mode = True