# Import your DeliveryPricing model
from models import DeliveryPricing, Category
from sqlalchemy.orm import sessionmaker
from database import engine


def populate_delivery_pricing_shopping_mall():
    Session = sessionmaker(bind=engine)
    session = Session()

    # Find the correct category for "Shopping Mall"
    shopping_mall_category = session.query(
        Category).filter_by(name="Shopping Mall").first()
    if not shopping_mall_category:
        print("Shopping Mall category not found.")
        session.close()
        return

    # Define the delivery pricing ranges and fees for Shopping Mall
    pricing_data = [
        {"min_amount": 100, "max_amount": 2999.99, "fee": 300},
        {"min_amount": 3000, "max_amount": 4999.99, "fee": 500},
        {"min_amount": 5000, "max_amount": 9999.99, "fee": 1000},
        {"min_amount": 10000, "max_amount": 14999.99, "fee": 1500},
        {"min_amount": 15000, "max_amount": 19999.99, "fee": 2000},
        {"min_amount": 20000, "max_amount": 24999.99, "fee": 2500},
        {"min_amount": 25000, "max_amount": 29999.99, "fee": 3000},
        {"min_amount": 30000, "max_amount": 34999.99, "fee": 3500},
        {"min_amount": 35000, "max_amount": 39999.99, "fee": 4000},
        {"min_amount": 40000, "max_amount": 44999.99, "fee": 4500},
        {"min_amount": 45000, "max_amount": 49999.99, "fee": 5000},
    ]

    # Insert each delivery pricing entry
    for data in pricing_data:
        delivery_pricing = DeliveryPricing(
            category_id=shopping_mall_category.id,
            min_order_amount=data["min_amount"],
            max_order_amount=data["max_amount"],
            fee=data["fee"]
        )
        session.add(delivery_pricing)

    session.commit()
    session.close()
    print("Delivery pricing population for Shopping Mall successful")


# Call the function
populate_delivery_pricing_shopping_mall()
