from sqlalchemy.orm import Session
from database import get_db, SessionLocal
import models


def check_database_population():
    db: Session = SessionLocal()  # Get a session directly
    try:
        # Check Sections
        sections = db.query(models.Section).all()
        print("Sections:")
        for section in sections:
            print(f"ID: {section.id}, Name: {section.name}")

        # Check Categories
        categories = db.query(models.Category).all()
        print("\nCategories:")
        for category in categories:
            print(
                f"ID: {category.id}, Name: {category.name}, Section ID: {category.section_id}")

        # Check Subcategories
        subcategories = db.query(models.Subcategory).all()
        print("\nSubcategories:")
        for subcategory in subcategories:
            print(
                f"ID: {subcategory.id}, Name: {subcategory.name}, Category ID: {subcategory.category_id}")
    finally:
        db.close()  # Ensure the session is closed


if __name__ == "__main__":
    check_database_population()
