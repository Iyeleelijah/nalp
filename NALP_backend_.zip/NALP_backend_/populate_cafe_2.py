from sqlalchemy.orm import sessionmaker
from database import engine, Base  # Import your engine and Base
from models import Category, Subcategory, Item, Section  # Import your models

categories_data = [
    {
        "name": "Cafe 2",
        "subcategories": [
            {
                "name": "Exceeding Grace Sharwama",
                "products": [
                    {"name": "Single beef sharwarma with chicken", "price": 1700,
                     "callback_data": "Single beef sharwarma with chicken|₦1700|Cafe 2"},
                    {"name": "Double beef sharwarma with chicken", "price": 2000,
                     "callback_data": "Double beef sharwarma with chicken|₦2000|Cafe 2"},
                    {"name": "Sharwarma with two sausages", "price": 2500,
                     "callback_data": "Sharwarma with two sausages|₦2500|Cafe 2"},
                    {"name": "Sharwarma with two sausages and suya", "price": 3000,
                     "callback_data": "Sharwarma with two sausages and suya|₦3000|Cafe 2"},
                    {"name": "Sharwarma with three beef with suya", "price": 3500,
                     "callback_data": "Sharwarma with three beef with suya|₦3500|Cafe 2"}
                ]
            },
            {
                "name": "Heavenly Confectionary",
                "products": [
                    {"name": "Corn dog", "price": 700,
                        "callback_data": "Corn dog|₦700|Cafe 2"},
                    {"name": "Corn dog with Mozzarella cheese", "price": 1200,
                     "callback_data": "Corn dog with Mozzarella cheese|₦1200|Cafe 2"},
                    {"name": "Corn dog with extra cheese", "price": 1500,
                     "callback_data": "Corn dog with extra cheese|₦1500|Cafe 2"},
                    {"name": "Corn dog with cheese stick", "price": 2000,
                     "callback_data": "Corn dog with cheese stick|₦2000|Cafe 2"},
                    {"name": "Sugar cane Juice", "price": 600,
                     "callback_data": "Sugar cane Juice|₦600|Cafe 2"}
                ]
            },
            {
                "name": "Mascot Barbecue and Chips",
                "products": [
                    {"name": "Small-sized chicken and chips with pack", "price": 2200,
                     "callback_data": "Small-sized chicken and chips with pack|₦2200|Cafe 2"},
                    {"name": "Mega chicken and chips with pack", "price": 2500,
                     "callback_data": "Mega chicken and chips with pack|₦2500|Cafe 2"},
                    {"name": "Bigger chicken and chips with pack", "price": 3200,
                     "callback_data": "Bigger chicken and chips with pack|₦3200|Cafe 2"},
                    {"name": "Biggest chicken and chips with pack", "price": 3700,
                     "callback_data": "Biggest chicken and chips with pack|₦3700|Cafe 2"},
                    {"name": "Chips only with pack", "price": 0,
                     "callback_data": "Chips only with pack|Cafe 2"},
                    {"name": "Turkey", "price": 0, "callback_data": "Turkey|Cafe 2"}
                ]
            },
            {
                "name": "Parfait So Yum",
                "products": [
                    {"name": "Cake parfait (cup size)", "price": 2000,
                     "callback_data": "Cake parfait (cup size)|₦2000|Cafe 2"},
                    {"name": "Cake parfait (Bowl size)", "price": 2500,
                     "callback_data": "Cake parfait (Bowl size)|₦2500|Cafe 2"},
                    {"name": "Rovo", "price": 600,
                        "callback_data": "Rovo|₦600|Cafe 2"},
                    {"name": "Oreo", "price": 700,
                        "callback_data": "Oreo|₦700|Cafe 2"},
                    {"name": "Chocolate", "price": 500,
                     "callback_data": "Chocolate|₦500|Cafe 2"},
                    {"name": "Ra sin", "price": 500,
                        "callback_data": "Ra sin|₦500|Cafe 2"},
                    {"name": "Almond seed", "price": 500,
                     "callback_data": "Almond seed|₦500|Cafe 2"},
                    {"name": "Sprinkles", "price": 500,
                     "callback_data": "Sprinkles|₦500|Cafe 2"},
                    {"name": "Cake (big size)", "price": 2000,
                     "callback_data": "Cake(big size)|₦2000|Cafe 2"},
                    {"name": "Cake (medium size)", "price": 1000,
                     "callback_data": "Cake(medium size)|₦1000|Cafe 2"},
                    {"name": "Cake (small size)", "price": 500,
                     "callback_data": "Cake(Small size)|₦500|Cafe 2"},
                    {"name": "Cookies", "price": 500,
                        "callback_data": "Cookies|₦500|Cafe 2"},
                    {"name": "Toppings", "price": 500,
                        "callback_data": "Toppings|₦500|Cafe 2"}
                ]
            }
        ]
    },

]


Base.metadata.create_all(bind=engine)


def populate_database(categories_data):
    # Create a new session
    Session = sessionmaker(bind=engine)
    session = Session()

    # Create a section instance (assuming you want to create a single section for all categories)
    section = Section(name="Cafe 2")
    session.add(section)
    session.flush()  # Flush to get the section ID

    # Iterate through the categories_data
    for category_data in categories_data:
        # Create a new category instance with the section_id
        category = Category(
            name=category_data["name"], section_id=section.id, callback_data=category_data["name"])
        session.add(category)
        session.flush()  # Flush to get the category ID for subcategories

        for subcategory_data in category_data["subcategories"]:
            # Create a new subcategory instance with callback_data
            subcategory = Subcategory(
                name=subcategory_data["name"],
                category=category,
                callback_data=subcategory_data.get(
                    "callback_data", subcategory_data["name"])  # Add this line
            )
            session.add(subcategory)
            session.flush()  # Flush to get the subcategory ID for items

            for product_data in subcategory_data["products"]:
                # Create a new item instance
                item = Item(
                    name=product_data["name"],
                    price=product_data.get("price", 0.0),
                    subcategory=subcategory,
                    description=product_data.get("callback_data", ""),
                    is_available=product_data.get("is_available", True),
                    callback_data=product_data.get(
                        "callback_data", product_data["callback_data"])
                )
                session.add(item)

    session.commit()  # Commit all changes to the database
    session.close()  # Close the session
    print("Database population successful")
populate_database(categories_data)
