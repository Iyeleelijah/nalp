import os
import threading
import subprocess
from http.server import HTTPServer, BaseHTTPRequestHandler

# Simple HTTP request handler


class SimpleHTTPRequestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(b'Telegram Bot is running!')


def run_server():
    # Get port from environment variable or use default
    port = int(os.environ.get("PORT", 10000))
    server_address = ('', port)
    httpd = HTTPServer(server_address, SimpleHTTPRequestHandler)
    print(f"Starting server on port {port}...")
    httpd.serve_forever()


def run_bot():
    # Run the bot script
    subprocess.run(["python", "food.py"])


if __name__ == "__main__":
    # Start the server in a separate thread
    server_thread = threading.Thread(target=run_server)
    server_thread.daemon = True
    server_thread.start()

    # Run the bot in the main thread
    run_bot()
